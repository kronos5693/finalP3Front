import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Container, Card, CardContent, Typography, CardMedia, 
  Grid, Paper, Button, Alert, CircularProgress, Box,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Dialog, DialogTitle, DialogContent, DialogActions, TextField, IconButton
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { useAuth } from '../context/AuthContext';
import { useCarrito } from '../context/CarritoContext';
import api from '../services/api';
import salidaService from '../services/Salida.service';
import NavBar from '../components/NavBar/navBar';

const PageReserva = () => {
  const { nombreExcursion } = useParams();
  const { usuario, isAuthenticated } = useAuth();
  const { agregarAlCarrito } = useCarrito();
  const navigate = useNavigate();

  const [excursion, setExcursion] = useState(null);
  const [salidas, setSalidas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  // Estados para el diálogo de cantidad
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedSalida, setSelectedSalida] = useState(null);
  const [cantidadPersonas, setCantidadPersonas] = useState(1);
  const [subtotal, setSubtotal] = useState(0);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    cargarDatos();
  }, [nombreExcursion, isAuthenticated]);

  const cargarDatos = async () => {
    try {
      setLoading(true);
      setError('');
      
      // Obtener la excursión por nombre
      const excursionData = await api.get(`/excursiones/nombre/${nombreExcursion}`);
      setExcursion(excursionData.data);

      // Obtener las salidas disponibles para esta excursión
      const salidasData = await salidaService.obtenerSalidasPorExcursion(
        excursionData.data._id,
        { futuras: 'true', habilitadas: 'true' }
      );
      setSalidas(salidasData);
    } catch (error) {
      console.error('Error al cargar datos:', error);
      setError(error.response?.data?.mensaje || 'Error al cargar la excursión');
    } finally {
      setLoading(false);
    }
  };

  const openQuantityDialog = (salida) => {
    setSelectedSalida(salida);
    setCantidadPersonas(1);
    setSubtotal(salida.excursion.precio * 1);
    setDialogOpen(true);
  };

  const updateQuantity = (newQuantity) => {
    if (newQuantity < 1) return;
    if (newQuantity > (selectedSalida?.disponibilidad || 1)) return;
    
    setCantidadPersonas(newQuantity);
    setSubtotal(newQuantity * (selectedSalida?.excursion?.precio || 0));
  };

  const handleAddToCart = async () => {
    if (!selectedSalida) return;
    
    try {
      await agregarAlCarrito(selectedSalida._id, cantidadPersonas);
      setSuccess(`¡Agregado al carrito! ${cantidadPersonas} persona(s) para la salida`);
      setDialogOpen(false);
      
      // Actualizar disponibilidad localmente
      setSalidas(salidas.map(salida => 
        salida._id === selectedSalida._id 
          ? { ...salida, disponibilidad: salida.disponibilidad - cantidadPersonas }
          : salida
      ));
      
      setTimeout(() => setSuccess(''), 3000);
    } catch (error) {
      setError(error.response?.data?.mensaje || 'Error al agregar al carrito');
      setDialogOpen(false);
    }
  };

  const groupSalidasByDate = () => {
    const grouped = {};
    salidas.forEach(salida => {
      const date = new Date(salida.fecha).toLocaleDateString('es-AR', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
      if (!grouped[date]) {
        grouped[date] = [];
      }
      grouped[date].push(salida);
    });
    return grouped;
  };

  if (loading) {
    return (
      <>
        <NavBar />
        <Container sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '60vh' }}>
          <CircularProgress />
        </Container>
      </>
    );
  }

  if (error && !excursion) {
    return (
      <>
        <NavBar />
        <Container sx={{ mt: 4 }}>
          <Alert severity="error">{error}</Alert>
          <Button onClick={() => navigate('/excursiones')} sx={{ mt: 2 }}>
            Volver a Excursiones
          </Button>
        </Container>
      </>
    );
  }

  if (!excursion) {
    return (
      <>
        <NavBar />
        <Container sx={{ mt: 4 }}>
          <Alert severity="error">Excursión no encontrada</Alert>
          <Button onClick={() => navigate('/excursiones')} sx={{ mt: 2 }}>
            Volver a Excursiones
          </Button>
        </Container>
      </>
    );
  }

  const groupedSalidas = groupSalidasByDate();

  return (
    <>
      <NavBar />
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        {error && (
          <Alert severity="error" onClose={() => setError('')} sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        {success && (
          <Alert severity="success" onClose={() => setSuccess('')} sx={{ mb: 2 }}>
            {success}
          </Alert>
        )}

        <Grid container spacing={4}>
          <Grid item xs={12} md={6}>
            <Card>
              <CardMedia
                component="img"
                image={excursion.img}
                alt={excursion.excursion}
                sx={{ height: 400, objectFit: 'cover' }}
              />
              <CardContent>
                <Typography variant="h4" gutterBottom>
                  {excursion.excursion}
                </Typography>
                <Typography variant="body1" paragraph>
                  {excursion.descripcion}
                </Typography>
                <Typography variant="h5" color="primary">
                  Precio: ${excursion.precio} por persona
                </Typography>
                {excursion.duracion && (
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    ⏱️ Duración: {excursion.duracion}
                  </Typography>
                )}
                {excursion.dificultad && (
                  <Typography variant="body2" color="text.secondary">
                    🏔️ Dificultad: {excursion.dificultad}
                  </Typography>
                )}
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} md={6}>
            <Paper elevation={3} sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                <ShoppingCartIcon sx={{ mr: 1 }} />
                <Typography variant="h5">
                  Salidas Disponibles
                </Typography>
              </Box>

              {salidas.length === 0 ? (
                <Alert severity="info" sx={{ mt: 2 }}>
                  No hay salidas disponibles en este momento. Por favor, contacta con nosotros.
                </Alert>
              ) : (
                <Box sx={{ mt: 2 }}>
                  {Object.entries(groupedSalidas).map(([date, salidasDelDia]) => (
                    <Box key={date} sx={{ mb: 4 }}>
                      <Typography variant="h6" color="primary" gutterBottom sx={{ borderBottom: '2px solid', borderColor: 'primary.main', pb: 1 }}>
                        📅 {date}
                      </Typography>
                      <TableContainer>
                        <Table size="small">
                          <TableHead>
                            <TableRow>
                              <TableCell>Horario</TableCell>
                              <TableCell align="center">Disponibilidad</TableCell>
                              <TableCell align="center">Precio c/u</TableCell>
                              <TableCell align="center">Acción</TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {salidasDelDia.map((salida) => (
                              <TableRow 
                                key={salida._id}
                                sx={{ 
                                  '&:hover': { backgroundColor: 'action.hover' },
                                  opacity: salida.disponibilidad === 0 ? 0.6 : 1
                                }}
                              >
                                <TableCell>
                                  <Typography variant="body2" fontWeight="medium">
                                    🕒 {salida.horario}
                                  </Typography>
                                </TableCell>
                                <TableCell align="center">
                                  <Box>
                                    <Typography variant="body2">
                                      {salida.disponibilidad} / {salida.capacidadMaxima}
                                    </Typography>
                                    {salida.disponibilidad === 0 && (
                                      <Typography variant="caption" color="error" display="block">
                                        AGOTADO
                                      </Typography>
                                    )}
                                    {salida.disponibilidad > 0 && salida.disponibilidad <= 3 && (
                                      <Typography variant="caption" color="warning.main" display="block">
                                        ÚLTIMOS {salida.disponibilidad} LUGARES
                                      </Typography>
                                    )}
                                  </Box>
                                </TableCell>
                                <TableCell align="center">
                                  <Typography variant="body2" fontWeight="medium">
                                    ${salida.excursion?.precio || 0}
                                  </Typography>
                                </TableCell>
                                <TableCell align="center">
                                  <Button
                                    variant="contained"
                                    size="small"
                                    onClick={() => openQuantityDialog(salida)}
                                    disabled={salida.disponibilidad === 0}
                                    startIcon={<ShoppingCartIcon />}
                                  >
                                    Reservar
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </TableContainer>
                    </Box>
                  ))}
                </Box>
              )}

              <Box sx={{ mt: 3, p: 2, bgcolor: 'grey.50', borderRadius: 2, border: '1px solid', borderColor: 'grey.300' }}>
                <Typography variant="body2" color="text.secondary">
                  💡 <strong>Instrucciones:</strong> Selecciona una salida, elige la cantidad de personas y agrégala a tu carrito. 
                  Puedes reservar múltiples salidas y finalizar la compra desde el carrito.
                </Typography>
              </Box>
            </Paper>
          </Grid>
        </Grid>

        {/* Diálogo para seleccionar cantidad */}
        <Dialog 
          open={dialogOpen} 
          onClose={() => setDialogOpen(false)}
          maxWidth="xs"
          fullWidth
        >
          <DialogTitle>
            Seleccionar cantidad de personas
          </DialogTitle>
          <DialogContent>
            {selectedSalida && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="body1" gutterBottom>
                  Salida: {selectedSalida.horario} - {new Date(selectedSalida.fecha).toLocaleDateString('es-AR')}
                </Typography>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  Disponibilidad: {selectedSalida.disponibilidad} lugares
                </Typography>
                
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', my: 3 }}>
                  <IconButton 
                    onClick={() => updateQuantity(cantidadPersonas - 1)}
                    disabled={cantidadPersonas <= 1}
                  >
                    <RemoveIcon />
                  </IconButton>
                  
                  <TextField
                    type="number"
                    value={cantidadPersonas}
                    onChange={(e) => updateQuantity(parseInt(e.target.value) || 1)}
                    inputProps={{ 
                      min: 1, 
                      max: selectedSalida.disponibilidad,
                      style: { textAlign: 'center', fontSize: '1.5rem', width: '80px' }
                    }}
                    variant="outlined"
                    sx={{ mx: 2 }}
                  />
                  
                  <IconButton 
                    onClick={() => updateQuantity(cantidadPersonas + 1)}
                    disabled={cantidadPersonas >= selectedSalida.disponibilidad}
                  >
                    <AddIcon />
                  </IconButton>
                </Box>
                
                <Box sx={{ mt: 3, p: 2, bgcolor: 'primary.light', borderRadius: 1 }}>
                  <Typography variant="h6" align="center" gutterBottom>
                    Detalle
                  </Typography>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography>Precio unitario:</Typography>
                    <Typography>${selectedSalida.excursion?.precio || 0}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography>Cantidad:</Typography>
                    <Typography>{cantidadPersonas} persona(s)</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1, pt: 1, borderTop: '1px solid' }}>
                    <Typography variant="h6">Subtotal:</Typography>
                    <Typography variant="h6" color="primary">
                      ${subtotal}
                    </Typography>
                  </Box>
                </Box>
              </Box>
            )}
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setDialogOpen(false)}>
              Cancelar
            </Button>
            <Button 
              variant="contained" 
              onClick={handleAddToCart}
              disabled={!cantidadPersonas || cantidadPersonas < 1}
            >
              Agregar al carrito
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    </>
  );
};

export default PageReserva;